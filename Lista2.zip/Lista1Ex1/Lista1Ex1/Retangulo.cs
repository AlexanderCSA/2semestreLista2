﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1
{
    internal class Retangulo
    {
        private int b;
        private int h;
        private int area;

        public Retangulo()
        { 

        this.b = 0;
        this.h = 0;
       
        }

        public Retangulo(int b, int h)
        {
            this.b = b;
            this.h = h;
      
        }

        public void setB(int b)
        {
            this.b = b;
            
        }
        public void setH(int h)
        {
            this.h = h;
           
        }
        public int getB()
        {
            return this.b;
        }
        public int getH()
        {
            return this.h;
        }

        public int getArea()
        {
            return this.area;
        }
        public void calcular()
        {
            this.area = this.b * this.h;
        }
    }
}
