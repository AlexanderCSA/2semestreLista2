﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangulo formato;
            formato = new Triangulo();

            Console.WriteLine("\n---------Exercício 12 da Lista 1---------\n");

            Console.Write("Digite o 1º Valor: ");
            formato.setV1(int.Parse(Console.ReadLine()));

            Console.Write("Digite o 2º Valor: ");
            formato.setV2(int.Parse(Console.ReadLine()));

            Console.Write("Digite o 3º Valor: ");
            formato.setV3(int.Parse(Console.ReadLine()));

            formato.calcular();

            Console.WriteLine("");

            Console.WriteLine("{0}", formato.getClassificacao());
        }
    }
}
